class WhileFlattenTransformer : public FlattenTransformer {
public:

	WhileFlattenTransformer(CompilerInstance* MI):FlattenTransformer(MI){}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {

				Stmt* WS = (*it)->getBody();
				if(WS)
				{
					CompoundStmt* sCS = dyn_cast<CompoundStmt>(WS);
					LabelStmt* lsmt;
					SrchResV res,cp;
					if( sCS )
					{
						res = ChkStmt(sCS,Stmt::WhileStmtClass);
						for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
						{
							StV* whv = new StV(),*dbody,*fpv = ICCopy(i->Parent);
							WhileStmt* wstm = dyn_cast<WhileStmt>(fpv[0][i->Index]);
							NullStmt* nstm = new (MyCI->getASTContext()) NullStmt(SourceLocation());
							BreakStmt* bstm = new (MyCI->getASTContext()) BreakStmt(SourceLocation());
							BuiltinType* bint = new BuiltinType(BuiltinType::Int);
							
							IntegerLiteral* litZero = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litOne  = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litTwo  = CrLiteralX(NextCaseLabel(),bint);	

							DeclStmt* SwVar = CreateSwVar(bint,litOne);
							DeclRefExpr* SwRef = Decl2DeclRef(SwVar,bint);

							BinaryOperator* swV0 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV1 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litOne ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV2 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litTwo ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());

							LabelStmt* lblCnt = AddNewLabel(nstm);
							LabelStmt* lblBrk = AddNewLabel(nstm);

							//convert continue --> goto (for evaluate loop condition)
							cp = ChkStmt(wstm->getBody(),Stmt::ContinueStmtClass,false);
							for(SrchResV::reverse_iterator j=cp.rbegin();j!=cp.rend();j++)
							{
								StV* ctv = ICCopy(j->Parent);
								ctv[0][j->Index] = new (MyCI->getASTContext()) GotoStmt(lblCnt,SourceLocation(),SourceLocation());
								setCmpndStV(j->Parent,ctv);
							}

							//convert break --> goto (for breaking whole loop)
							cp = ChkStmt(wstm->getBody(),Stmt::BreakStmtClass,false);
							for(SrchResV::reverse_iterator j=cp.rbegin();j!=cp.rend();j++)
							{
								StV* ctv = ICCopy(j->Parent);
								ctv[0][j->Index] = new (MyCI->getASTContext()) GotoStmt(lblBrk,SourceLocation(),SourceLocation());
								setCmpndStV(j->Parent,ctv);
							}
							
							CaseStmt** CaseGrp= new (MyCI->getASTContext()) CaseStmt*;
							
							CaseGrp[0] = new (MyCI->getASTContext()) CaseStmt(litOne,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							//while condition --> IF
							StV* wCaseCond = new StV();
							IfStmt* ismt = new (MyCI->getASTContext()) IfStmt(SourceLocation(),NULL,wstm->getCond(),StmttoCompound(swV2),SourceLocation(),StmttoCompound(swV0));
							wCaseCond[0].push_back(ismt);
							wCaseCond[0].push_back(bstm);
							CaseGrp[0]->setSubStmt(StVtoCompound(wCaseCond));
							CaseGrp[0]->setNextSwitchCase(NULL);

							CaseGrp[1] = new (MyCI->getASTContext()) CaseStmt(litTwo,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							//while body
							StV* wCaseBody = ICCopy(wstm->getBody());
							wCaseBody[0].push_back(lblCnt);
							wCaseBody[0].push_back(swV1);
							wCaseBody[0].push_back(bstm);
							CaseGrp[1]->setSubStmt(StVtoCompound(wCaseBody));
							CaseGrp[1]->setNextSwitchCase(CaseGrp[0]);

							CompoundStmt* csst = new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),(Stmt**)CaseGrp,2,SourceLocation(),SourceLocation());

							SwitchStmt* ssmt = new (MyCI->getASTContext()) SwitchStmt(NULL,SwRef);
							ssmt->setBody(csst);
							ssmt->setSwitchCaseList(CaseGrp[1]);

							whv[0].push_back(SwVar);
							
							//while condition
							BinaryOperator* wbop = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero,BinaryOperator::Opcode::NE,bint->desugar(),SourceLocation());
							whv[0].push_back( new (MyCI->getASTContext()) WhileStmt(NULL,wbop,StmttoCompound(ssmt),SourceLocation()) );

							whv[0].push_back(lblBrk);

							fpv[0][i->Index]= ( StVtoCompound(whv) );

							setCmpndStV(i->Parent,fpv);
						}
					}
				}
		}
	}
};