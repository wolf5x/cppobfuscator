class SwitchFlattenTransformer : public FlattenTransformer {
public:

	SwitchFlattenTransformer(CompilerInstance* MI):FlattenTransformer(MI){}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {

				Stmt* WS = (*it)->getBody();
				if(WS)
				{
					CompoundStmt* sCS = dyn_cast<CompoundStmt>(WS);
					LabelStmt* lsmt;
					SrchResV res,cp;
					if( sCS )
					{
						res = ChkStmt(sCS,Stmt::SwitchStmtClass);
						for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
						{
							StV* whv = new StV(),*dbody,*fpv = ICCopy(i->Parent);
							SwitchStmt* cstm = dyn_cast<SwitchStmt>(fpv[0][i->Index]);
							NullStmt* nstm = new (MyCI->getASTContext()) NullStmt(SourceLocation());
							BreakStmt* bstm = new (MyCI->getASTContext()) BreakStmt(SourceLocation());
							BuiltinType* bint = new BuiltinType(BuiltinType::Int);
							
							IntegerLiteral* litZero   = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litOne    = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litTwo    = CrLiteralX(NextCaseLabel(),bint);

							DeclStmt* SwVar = CreateSwVar(bint,litOne);
							DeclRefExpr* SwRef = Decl2DeclRef(SwVar,bint);
							
							BinaryOperator* swV0 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero  ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV1 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litOne   ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV2 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litTwo   ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							
							LabelStmt* lblBrk = AddNewLabel(nstm);

							//convert break --> goto (for breaking whole loop)
							cp = ChkStmt(cstm->getBody(),Stmt::BreakStmtClass,false);
							for(SrchResV::reverse_iterator j=cp.rbegin();j!=cp.rend();j++)
							{
								StV* ctv = ICCopy(j->Parent);
								ctv[0][j->Index] = new (MyCI->getASTContext()) GotoStmt(lblBrk,SourceLocation(),SourceLocation());
								setCmpndStV(j->Parent,ctv);
							}

							CaseStmt** CaseGrp= new (MyCI->getASTContext()) CaseStmt*;
							
							StV* swfV = new StV();
							SwitchCase* scs = cstm->getSwitchCaseList();
							while(scs!=NULL)
							{
								LabelStmt* lblimp = AddNewLabel(nstm); 
								GotoStmt* glbl = new (MyCI->getASTContext()) GotoStmt(lblimp,SourceLocation(),SourceLocation());
								swfV[0].insert(swfV[0].begin(),scs->getSubStmt());
								swfV[0].insert(swfV[0].begin(),lblimp);
								if(scs->getStmtClass() == Stmt::CaseStmtClass)
									dyn_cast<CaseStmt>(scs)   ->setSubStmt( StmttoCompound(glbl) );
								else
									dyn_cast<DefaultStmt>(scs)->setSubStmt( StmttoCompound(glbl) );

								scs = scs->getNextSwitchCase();
							}
							
							CaseGrp[0] = new (MyCI->getASTContext()) CaseStmt(litOne,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							
							StV* sCaseJmp  = new StV();
							sCaseJmp[0].push_back(cstm);
							sCaseJmp[0].push_back(swV0);
							sCaseJmp[0].push_back(bstm);
							CaseGrp[0]->setSubStmt(StVtoCompound(sCaseJmp));
							CaseGrp[0]->setNextSwitchCase(NULL);

							CaseGrp[1] = new (MyCI->getASTContext()) CaseStmt(litTwo,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							
							StV* sCaseBody = new StV();
							sCaseBody[0].push_back(StVtoCompound(swfV));
							sCaseBody[0].push_back(lblBrk);
							sCaseBody[0].push_back(swV0);
							sCaseBody[0].push_back(bstm);
							CaseGrp[1]->setSubStmt(StVtoCompound(sCaseBody));
							CaseGrp[1]->setNextSwitchCase(CaseGrp[0]);

							CompoundStmt* csst = new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),(Stmt**)CaseGrp,2,SourceLocation(),SourceLocation());

							SwitchStmt* ssmt = new (MyCI->getASTContext()) SwitchStmt(NULL,SwRef);
							ssmt->setBody(csst);
							ssmt->setSwitchCaseList(CaseGrp[1]);

							whv[0].push_back(SwVar);
							
							//while condition
							BinaryOperator* wbop = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero,BinaryOperator::Opcode::NE,bint->desugar(),SourceLocation());
							whv[0].push_back( new (MyCI->getASTContext()) WhileStmt(NULL,wbop,StmttoCompound(ssmt),SourceLocation()) );

							
							fpv[0][i->Index]= ( StVtoCompound(whv) );

							setCmpndStV(i->Parent,fpv);
						}
					}
				}
		}
	}
};