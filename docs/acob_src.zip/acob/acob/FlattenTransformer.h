class FlattenTransformer : public BasicTransformer {
public:

	FlattenTransformer(CompilerInstance* MI):BasicTransformer(MI){}

	IdentifierInfo* getSwVar()
	{
		static int currVar=0;
		string swN("____oOOSwVarOOo____");
		return &getUniqueIdentifier(swN,currVar);
	}

	DeclStmt* CreateSwVar(BuiltinType* bint,IntegerLiteral* val)
	{
		VarDecl* vds = VarDecl::Create(MyCI->getASTContext(),MyCI->getASTContext().getTranslationUnitDecl()
			,SourceLocation(),getSwVar(),bint->desugar(),NULL,VarDecl::StorageClass::None);
		vds->setInit(val);
		
		return new (MyCI->getASTContext()) DeclStmt(DeclGroupRef (vds),SourceLocation(),SourceLocation());
	}

};