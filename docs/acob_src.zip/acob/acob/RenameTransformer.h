class RenameTransformer : public BasicTransformer {
public:

	RenameTransformer(CompilerInstance* MI):BasicTransformer(MI){}

	void RenameDecl( Decl* D )
	{
		static std::string idenN("_");
		int i = 0;

		NamedDecl *VD = dyn_cast<NamedDecl>(D);
		if(!VD) return;

		//IdentifierInfo &info = MyCI->getPreprocessor().getIdentifierTable().get(idenN);
		IdentifierInfo &info = getUniqueIdentifier(idenN,i);
		VD->setDeclName(DeclarationName(&info));
		idenN.append("_");
	}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		
		DeclGroupRef::iterator it;
		for(it = D.begin();
		    it != D.end();
		    it++) {
			
			DeclContext *DC = dyn_cast<DeclContext>(*it);
			if(DC)
			{
				for(DeclContext::decl_iterator i = DC->decls_begin();i!=DC->decls_end();i++)
				{
					RenameDecl(*i);
				}
			}
			RenameDecl(*it);
		}
	}
};