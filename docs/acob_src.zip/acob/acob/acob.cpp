
#include "stdafx.h"

typedef std::vector<ASTConsumer*> ATs;

#include "BasicTransformer.h"
#include "FlattenTransformer.h"
#include "RenameTransformer.h"
#include "Compoundizer.h"
#include "ForTransformer.h"
#include "DoTransformer.h"
#include "WhileFlattenTransformer.h"
#include "IfFlattenTransformer.h"
#include "SwitchFlattenTransformer.h"
#include "PrinterConsumer.h"

DEFINE_string(out, "res.c", "name of output file");
DEFINE_string(ord, "sfdwi",
	"Order of performing the obfuscation primitives, they can be added in any order or repeated where : \
	\ns: Switch Statement \
	\nf: For Statement \
	\nd: Do Statement \
	\nw: While Statement \
	\ni: If Statement \
	\n\nExamples : sfdwi, sfdwis, fdwwwi\n");

int main(int argc, char *argv[])
{

	::google::SetUsageMessage("C Code Obfuscator");
	::google::ParseCommandLineFlags(&argc, &argv, true);

	if(argc<=1)
	{
		std::cout<<"no input file provided"<<std::endl;
		return 1;
	}

	CompilerInstance MyCI;

	MyCI.setLLVMContext(new llvm::LLVMContext );

	TextDiagnosticBuffer DiagsBuffer; 
	Diagnostic Diags(&DiagsBuffer);

	int iargc=4;
	const char** iargv=new const char*[4];
	iargv[0]="C:\\path.exe";
	iargv[1]="-cc1";
	iargv[2]="-fms-extensions";
	iargv[3]="-w";

	CompilerInvocation::CreateFromArgs(MyCI.getInvocation(), iargv+2, iargv+iargc, Diags);

	MyCI.createDiagnostics(0, NULL);
	if (!MyCI.hasDiagnostics())
		return 1;

	MyCI.createSourceManager();
	MyCI.createFileManager();

	MyCI.setTarget(TargetInfo::CreateTargetInfo(MyCI.getDiagnostics(),
		MyCI.getTargetOpts()));

	MyCI.createPreprocessor();

	char* f= argv[1];
	const FileEntry *file = MyCI.getFileManager().getFile(f);
	MyCI.getSourceManager().createMainFileID(file, SourceLocation());

	MyCI.createASTContext();
	if (MyCI.getDiagnostics().getNumErrors())
	{
		std::cout<<"Errors Occured/n";
		exit(0);
	}

	llvm::raw_ostream *OS = MyCI.createOutputFile(FLAGS_out,false,"*.c","*.c");
	RenameTransformer rt(&MyCI);
	Compoundizer czer(&MyCI);
	ForTransformer ft(&MyCI);
	DoTransformer dt(&MyCI);
	WhileFlattenTransformer wft(&MyCI);
	IfFlattenTransformer ift(&MyCI);
	SwitchFlattenTransformer sft(&MyCI);
	PrintConsumer prc(OS,&MyCI);
	InclPrintConsumer ipr(OS,&MyCI);
	ATs Cs;

	Cs.push_back(&ipr);
	Cs.push_back(&czer);
	//Cs.push_back(&rt);

	for(std::string::iterator i = FLAGS_ord.begin();i!=FLAGS_ord.end();i++)
	{
		switch(*i)
		{
		case 's':
			Cs.push_back(&sft);
			break;
		case 'f':
			Cs.push_back(&ft);
			break;
		case 'd':
			Cs.push_back(&dt);
			break;
		case 'w':
			Cs.push_back(&wft);
			break;
		case 'i':
			Cs.push_back(&ift);
			break;
		}
	}

	Cs.push_back(&prc);
	//Cs.push_back(CreateASTPrinter(OS)); 

	CustomParseAST(MyCI.getPreprocessor(), Cs , MyCI.getASTContext(),
		true,
		true, 0, *OS);

	OS->flush();

	return 0;
}

