class Compoundizer : public BasicTransformer {
public:

	Compoundizer(CompilerInstance* MI):BasicTransformer(MI){}

	template<class T>
	void CmpizeBody(SrchResV res,void (T::*sset)(Stmt *) , Stmt* (T::*sget)() )
	{
		for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
		{
			StV* whv = new StV(),*fbody,*fpv = ICCopy(i->Parent);
			T* fstm = dyn_cast<T>(fpv[0][i->Index]);
			if((fstm->*sget)()!=NULL)
				(fstm->*sset)(StmttoCompound((fstm->*sget)()));
		}
	}

	void CmpizCase(SrchResV res)
	{
		for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
		{
			StV* whv = new StV(),*fpv = ICCopy(i->Parent);int j=0;
			SwitchStmt* fstm = dyn_cast<SwitchStmt>(fpv[0][i->Index]);
			SwitchCase* scs = fstm->getSwitchCaseList();
		}
	}

	void CaseReOrder(SwitchCase* &scs)
	{
		SwitchCase* c1=scs,*c2=c1->getNextSwitchCase(),*tmp;
		c1->setNextSwitchCase(NULL);
		while(c2!=NULL)
		{
			tmp = c2->getNextSwitchCase();
			c2->setNextSwitchCase(c1);
			c1 = c2;
			c2 = tmp;
		}
		scs = c1;
	}

	void CmpizSwitch(SrchResV res)
	{
		for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
		{
			StV* whv = new StV(),*fpv = ICCopy(i->Parent);;int j=0;
			SwitchStmt* fstm = dyn_cast<SwitchStmt>(fpv[0][i->Index]);
			SwitchCase* scs = fstm->getSwitchCaseList();
			CaseReOrder(scs);
			fstm->setSwitchCaseList(scs);
			for (Stmt::child_iterator I = fstm->child_begin(), E = fstm->child_end(); I !=E; )
				if (Stmt* Child = *I++)
				{
					if(Child->getStmtClass()==Stmt::CompoundStmtClass)
					{
						bool fin=false;
						j=0;
						Stmt::child_iterator I = Child->child_begin(), E = Child->child_end(); 
						while(true){
							if (Stmt* Child = *I++)
							{
								if(fin || (Child->getStmtClass()==Stmt::CaseStmtClass&&j>0))
								{
									whv[0].insert(whv[0].begin(),dyn_cast<CaseStmt>(scs)->getSubStmt());
									CompoundStmt* ssyy = StVtoCompound(whv);
									if(scs->getStmtClass() == Stmt::CaseStmtClass)
										dyn_cast<CaseStmt>(scs)   ->setSubStmt(new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),(Stmt**) &(ssyy),1,SourceLocation(),SourceLocation()));
									else
										dyn_cast<DefaultStmt>(scs)->setSubStmt(StVtoCompound(whv));
									scs = scs->getNextSwitchCase();
									whv = new StV();
									if(fin)
										break;
								}
								else if(Child->getStmtClass()!=Stmt::CaseStmtClass)
									whv[0].push_back(Child);
								if(!(I !=E))
									fin=true;
								j++;
							}
						}
						//SwitchStmt* smmt = new (MyCI->getASTContext()) SwitchStmt(NULL,fstm->getCond());
						//smmt->setSwitchCaseList(fstm->getSwitchCaseList());
						//fpv[0][i->Index] = smmt;
					}
					//setCmpndStV(i->Parent,fpv);
				}
				scs = fstm->getSwitchCaseList();
				CaseReOrder(scs);
				fstm->setSwitchCaseList(scs);
		}
	}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {

				Stmt* WS = (*it)->getBody();
				
				if(WS)
				{
					CompoundStmt* sCS = dyn_cast<CompoundStmt>(WS);
					LabelStmt* lsmt;
					SrchResV res,cp;
					if( sCS )
					{
						CmpizeBody<DoStmt>   (ChkStmt(sCS,Stmt::DoStmtClass) , &DoStmt::setBody , &DoStmt::getBody);
						CmpizeBody<WhileStmt>(ChkStmt(sCS,Stmt::WhileStmtClass) , &WhileStmt::setBody , &WhileStmt::getBody);
						CmpizeBody<ForStmt>  (ChkStmt(sCS,Stmt::ForStmtClass) , &ForStmt::setBody , &ForStmt::getBody);
						CmpizeBody<IfStmt>   (ChkStmt(sCS,Stmt::IfStmtClass) , &IfStmt::setThen , &IfStmt::getThen);
						CmpizeBody<IfStmt>   (ChkStmt(sCS,Stmt::IfStmtClass) , &IfStmt::setElse , &IfStmt::getElse);
						CmpizSwitch          (ChkStmt(sCS,Stmt::SwitchStmtClass) );
					  //CompizLabel
					}
				}
		}
	}
};