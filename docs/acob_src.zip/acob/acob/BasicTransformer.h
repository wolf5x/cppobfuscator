
void CustomParseAST(Preprocessor &PP, ATs Consumers,
                     ASTContext &Ctx, bool enter,
                     bool CompleteTranslationUnit,
                     CodeCompleteConsumer *CompletionConsumer,
					 llvm::raw_ostream &Out) {
  

  Sema S(PP, Ctx, *Consumers[0], CompleteTranslationUnit, CompletionConsumer);
  Parser P(PP, S);
 
  PP.EnterMainSourceFile();
  P.Initialize();
  

  Consumers[0]->Initialize(Ctx);

  if (SemaConsumer *SC = dyn_cast<SemaConsumer>(&Consumers[0]))
    SC->InitializeSema(S);

  if (ExternalASTSource *External = Ctx.getExternalSource()) {
    if (ExternalSemaSource *ExternalSema =
          dyn_cast<ExternalSemaSource>(External))
      ExternalSema->InitializeSema(S);

    External->StartTranslationUnit(Consumers[0]);
  }

  

  Parser::DeclGroupPtrTy ADecl;

  while (!P.ParseTopLevelDecl(ADecl)) {  // Not end of file.
	  if (ADecl)
	  {
		  for(ATs::iterator i=Consumers.begin();i!=Consumers.end();i++)
		  {
			  (*i)->HandleTopLevelDecl(ADecl.getAsVal<DeclGroupRef>());
		  }
	  }
  };

  for(ATs::iterator i = Consumers.begin();i!=Consumers.end();i++)
	(*i)->HandleTranslationUnit(Ctx);

  if (ExternalSemaSource *ESS =
        dyn_cast_or_null<ExternalSemaSource>(Ctx.getExternalSource()))
    ESS->ForgetSema();

  if (SemaConsumer *SC = dyn_cast<SemaConsumer>(Consumers[0]))
    SC->ForgetSema();

}

struct StmtSearchRes
{
	Stmt* Parent;
	int   Index;

	StmtSearchRes(Stmt* s,int i):Parent(s),Index(i){}
};

typedef std::vector<StmtSearchRes> SrchResV;

std::vector<Stmt::StmtClass> LoopBanList = list_of (Stmt::SwitchStmtClass)(Stmt::ForStmtClass)
												   (Stmt::DoStmtClass)(Stmt::WhileStmtClass);

class BasicTransformer : public ASTConsumer {
public:
	CompilerInstance* MyCI;
	BasicTransformer(CompilerInstance* MI):MyCI(MI){}

	typedef llvm::SmallVector<Stmt*, 32> StV;

	StV* ICCopy(Stmt* sCS,bool parent=false)
	{
		StV *ggo = new StV();
		for (Stmt::child_iterator I = sCS->child_begin(), E = sCS->child_end(); I !=E; )
			if (Stmt* Child = *I++)
				ggo[0].push_back(Child);
		return ggo;
	}

	SrchResV ChkStmt(Stmt* sCS,Stmt::StmtClass cmpClass,
		bool cflow=true )
	{
		int j=0,cand=-1;
		SrchResV vres;

		for (Stmt::child_iterator I = sCS->child_begin(), E = sCS->child_end(); I !=E;j++ )
			if (Stmt* Child = *I++)
			{
				Stmt::StmtClass curStmt = Child->getStmtClass();
				if( curStmt == cmpClass )
				{
					vres.push_back(StmtSearchRes(sCS,j));
				}

				if(cflow || (std::find(LoopBanList.begin(),LoopBanList.end(),curStmt ) == LoopBanList.end()) )
				{
					SrchResV res = ChkStmt( Child , cmpClass , cflow );
					vres.insert(vres.end(),res.begin(),res.end());
				}
			}

		return vres;
	}

	IdentifierInfo& getUniqueIdentifier(string sname,int& ccnt)
	{
		int csz = MyCI->getPreprocessor().getIdentifierTable().size();
		while(1)
		{
			string lbl = sname;
			lbl.append(boost::lexical_cast<string>(ccnt++));
			IdentifierInfo& info = MyCI->getPreprocessor().getIdentifierTable().get(lbl);
			if(csz < MyCI->getPreprocessor().getIdentifierTable().size())
				return info;
		}
	}

	LabelStmt* AddNewLabel(Stmt* stBody)
	{
		static int currLabel=0;
		string lbl("____lbl____");
		IdentifierInfo &info = getUniqueIdentifier(lbl,currLabel);
		return new (MyCI->getASTContext()) LabelStmt(SourceLocation(),&info,StmttoCompound(stBody)) ;
	}

	bool LoopJtoGoto(Stmt* stBody,Stmt::StmtClass stClass,LabelStmt* lsmt)
	{
		SrchResV cp = ChkStmt(stBody,stClass,false);
		for(SrchResV::reverse_iterator j=cp.rbegin();j!=cp.rend();j++)
		{
			StV* ctv = ICCopy(j->Parent);
			ctv[0][j->Index] = new (MyCI->getASTContext()) GotoStmt(lsmt,SourceLocation(),SourceLocation());
			setCmpndStV(j->Parent,ctv);
		}
		if(cp.size()>0) return true;
		else return false;
	}

	int NextCaseLabel()
	{
		static int curr=1010100;
		return ++curr;
	}

	inline CompoundStmt* StVtoCompound(StV *inp )
	{
		return new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),&inp[0][0],inp[0].size(),SourceLocation(),SourceLocation() );
	}

	inline CompoundStmt* StmttoCompound (Stmt* s)
	{
		return new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),(Stmt**)(&s),1,SourceLocation(),SourceLocation() );
	}

	inline IntegerLiteral* CrLiteralX(int x,BuiltinType* bint)
	{
		return new (MyCI->getASTContext()) IntegerLiteral(llvm::APInt(32,x),bint->desugar(),SourceLocation());
	}

	inline DeclRefExpr* Decl2DeclRef(DeclStmt* ds,BuiltinType* bint)
	{
		return new (MyCI->getASTContext()) DeclRefExpr(dyn_cast<ValueDecl>( ds->getDeclGroup().getSingleDecl() ),bint->desugar(),SourceLocation());
	}

	void setCmpndStV(Stmt* fparent,StV* fpv)
	{
		switch(fparent->getStmtClass())
		{
		case Stmt::CompoundStmtClass:
			dyn_cast<CompoundStmt>(fparent)->setStmts(MyCI->getASTContext(), reinterpret_cast<Stmt**>(&fpv[0][0]) ,fpv[0].size());
			break;
		case Stmt::ForStmtClass:
			dyn_cast<ForStmt>(fparent)->setBody((Stmt*)(fpv[0][0]));
			break;
		case Stmt::DoStmtClass:
			dyn_cast<DoStmt>(fparent)->setBody((Stmt*)(fpv[0][0]) );
			break;
		case Stmt::WhileStmtClass:
			dyn_cast<WhileStmt>(fparent)->setBody((Stmt*)(fpv[0][0]) );
			break;
		}
		
	}
};