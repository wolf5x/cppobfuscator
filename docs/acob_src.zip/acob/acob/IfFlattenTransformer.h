class IfFlattenTransformer : public FlattenTransformer {
public:

	IfFlattenTransformer(CompilerInstance* MI):FlattenTransformer(MI){}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {

				Stmt* WS = (*it)->getBody();
				if(WS)
				{
					CompoundStmt* sCS = dyn_cast<CompoundStmt>(WS);
					LabelStmt* lsmt;
					SrchResV res,cp;
					if( sCS )
					{
						res = ChkStmt(sCS,Stmt::IfStmtClass);
						for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
						{
							StV* whv = new StV(),*dbody,*fpv = ICCopy(i->Parent),*unj = new StV();
							IfStmt* istm = dyn_cast<IfStmt>(fpv[0][i->Index]);
							NullStmt* nstm = new (MyCI->getASTContext()) NullStmt(SourceLocation());
							BreakStmt* bstm = new (MyCI->getASTContext()) BreakStmt(SourceLocation());
							ContinueStmt* cstm = new (MyCI->getASTContext()) ContinueStmt(SourceLocation());
							BuiltinType* bint = new BuiltinType(BuiltinType::Int);
							LabelStmt* lbstm,*lcstm;
							bool addJs=false;
							
							IntegerLiteral* litCFalse   = CrLiteralX(0,bint);
							IntegerLiteral* litZero     = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litOne      = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litTwo      = CrLiteralX(NextCaseLabel(),bint);
							IntegerLiteral* litThree    = CrLiteralX(NextCaseLabel(),bint);

							DeclStmt* SwVar = CreateSwVar(bint,litOne);
							DeclRefExpr* SwRef = Decl2DeclRef(SwVar,bint);

							BinaryOperator* swV0 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero  ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV1 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litOne   ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV2 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litTwo   ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());
							BinaryOperator* swV3 = new (MyCI->getASTContext()) BinaryOperator(SwRef,litThree ,BinaryOperator::Opcode::Assign,bint->desugar(),SourceLocation());

							lbstm = AddNewLabel(bstm);
							lcstm = AddNewLabel(cstm);
							
							unj[0].push_back(lbstm);
							unj[0].push_back(lcstm);
							
							IfStmt* ifst = new (MyCI->getASTContext()) IfStmt(SourceLocation(),NULL,litCFalse,StVtoCompound(unj));

							addJs  = LoopJtoGoto(istm->getThen(),Stmt::ContinueStmtClass,lcstm);
							addJs |= LoopJtoGoto(istm->getThen(),Stmt::BreakStmtClass,lbstm);
							if(istm->getElse()!=NULL)
							{
								addJs |= LoopJtoGoto(istm->getElse(),Stmt::ContinueStmtClass,lcstm);
								addJs |= LoopJtoGoto(istm->getElse(),Stmt::BreakStmtClass,lbstm);
							}
							
							
							CaseStmt** CaseGrp= new (MyCI->getASTContext()) CaseStmt*[3];
							
							CaseGrp[0] = new (MyCI->getASTContext()) CaseStmt(litOne,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							//If condition --> switch jumps
							StV* iCaseCond = new StV();
							IfStmt* ismt = new (MyCI->getASTContext()) IfStmt(SourceLocation(),NULL,istm->getCond(),StmttoCompound(swV2),SourceLocation(),StmttoCompound(swV3));
							iCaseCond[0].push_back(ismt);
							iCaseCond[0].push_back(bstm);
							CaseGrp[0]->setSubStmt(StVtoCompound(iCaseCond));
							CaseGrp[0]->setNextSwitchCase(NULL);

							CaseGrp[1] = new (MyCI->getASTContext()) CaseStmt(litTwo,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							//Then
							StV* iCaseThen = ICCopy(istm->getThen());
							iCaseThen[0].push_back(swV0);
							iCaseThen[0].push_back(bstm);
							CaseGrp[1]->setSubStmt(StVtoCompound(iCaseThen));
							CaseGrp[1]->setNextSwitchCase(CaseGrp[0]);

							CaseGrp[2] = new (MyCI->getASTContext()) CaseStmt(litThree,NULL,SourceLocation(),SourceLocation(),SourceLocation());
							//Else
							StV* iCaseElse = (istm->getElse()!=NULL)? ICCopy(istm->getElse()):ICCopy(nstm);
							iCaseElse[0].push_back(swV0);
							iCaseElse[0].push_back(bstm);
							CaseGrp[2]->setSubStmt(StVtoCompound(iCaseElse));
							CaseGrp[2]->setNextSwitchCase(CaseGrp[1]);
						
							CompoundStmt* csst = new (MyCI->getASTContext()) CompoundStmt(MyCI->getASTContext(),(Stmt**)CaseGrp,3,SourceLocation(),SourceLocation());

							SwitchStmt* ssmt = new (MyCI->getASTContext()) SwitchStmt(NULL,SwRef);
							ssmt->setBody(csst);
							ssmt->setSwitchCaseList(CaseGrp[2]);
							
							whv[0].push_back(SwVar);
							
							//while condition
							BinaryOperator* wbop = new (MyCI->getASTContext()) BinaryOperator(SwRef,litZero,BinaryOperator::Opcode::NE,bint->desugar(),SourceLocation());
							whv[0].push_back( new (MyCI->getASTContext()) WhileStmt(NULL,wbop,StmttoCompound(ssmt),SourceLocation()) );
							
							if(addJs)
								whv[0].push_back( StmttoCompound(ifst) );		
							
							fpv[0][i->Index]= ( StVtoCompound(whv) );

							setCmpndStV(i->Parent,fpv);
						}
					}
				}
		}
	}
};