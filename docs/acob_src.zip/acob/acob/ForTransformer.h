class ForTransformer : public BasicTransformer {
public:

	ForTransformer(CompilerInstance* MI):BasicTransformer(MI){}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {

				Stmt* WS = (*it)->getBody();
				if(WS)
				{
					CompoundStmt* sCS = dyn_cast<CompoundStmt>(WS);
					LabelStmt* lsmt;
					SourceLocation noloc;
					SrchResV res,cp;
					if( sCS )
					{
						res = ChkStmt(sCS,Stmt::ForStmtClass);
						for(SrchResV::reverse_iterator i=res.rbegin();i!=res.rend();i++)
						{
							StV* whv = new StV(),*fbody,*fpv = ICCopy(i->Parent);
							ForStmt* fstm = dyn_cast<ForStmt>(fpv[0][i->Index]);
							NullStmt* nstm = new (MyCI->getASTContext()) NullStmt(SourceLocation());
							BuiltinType* bint = new BuiltinType(BuiltinType::Int);
							
							fbody = ICCopy(fstm->getBody());
							Expr* incS = fstm->getInc()!=NULL?fstm->getInc():CrLiteralX(1,bint); 
							lsmt = AddNewLabel(incS);
							fbody[0].push_back(lsmt);
							fstm->setBody( StVtoCompound(fbody) );

							cp = ChkStmt(fstm->getBody(),Stmt::ContinueStmtClass,false);
							for(SrchResV::reverse_iterator j=cp.rbegin();j!=cp.rend();j++)
							{
								StV* ctv = ICCopy(j->Parent);
								ctv[0][j->Index] = new (MyCI->getASTContext()) GotoStmt(lsmt,SourceLocation(),SourceLocation());
								setCmpndStV(j->Parent,ctv);
							}

							Stmt* init = fstm->getInit()!=NULL?fstm->getInit():nstm; 
							Expr* cond = fstm->getCond()!=NULL?fstm->getCond():CrLiteralX(1,bint); 
							whv[0].push_back( init );
							whv[0].push_back( new (MyCI->getASTContext()) WhileStmt(NULL,cond,fstm->getBody(),noloc) );
							
							fpv[0][i->Index]= ( StVtoCompound(whv) );

							setCmpndStV(i->Parent,fpv);
						}
					}
				}
		}
	}
};