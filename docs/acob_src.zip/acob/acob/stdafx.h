
#pragma once

#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <fstream>

#include "clang/Frontend/CompilerInstance.h"
#include "clang/Frontend/TextDiagnosticBuffer.h"
#include "clang/Frontend/HeaderSearchOptions.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/Frontend/ASTConsumers.h"
#include "clang/Basic/TargetInfo.h"
#include "clang/AST/AST.h"
#include "clang/AST/ASTConsumer.h"
#include "clang/AST/ASTContext.h"
#include "clang/Sema/ParseAST.h"
#include "clang/Parse/Scope.h"
#include "clang/Lex/HeaderSearch.h"
#include "clang/Lex/Preprocessor.h"
#include "clang/Sema/ParseAST.h"
#include "Sema/Sema.h"
#include "clang/Sema/CodeCompleteConsumer.h"
#include "clang/Sema/SemaConsumer.h"
#include "clang/Sema/ExternalSemaSource.h"
#include "clang/AST/ASTConsumer.h"
#include "clang/AST/ExternalASTSource.h"
#include "clang/AST/Stmt.h"
#include "clang/Parse/Parser.h"
#include "llvm/LLVMContext.h"
#include "llvm/Target/TargetSelect.h"

#include "clang/Basic/FileManager.h"
#include "clang/Basic/SourceManager.h"

#include <boost/lexical_cast.hpp>
#include <boost/assign/list_of.hpp>

#include <gflags/gflags.h>

using namespace clang;

using namespace std;

using namespace boost::assign;

