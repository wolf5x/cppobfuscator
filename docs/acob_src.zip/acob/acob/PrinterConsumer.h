class InclPrintConsumer : public ASTConsumer {
public:

	llvm::raw_ostream &Out;
	CompilerInstance* MyCI;
	std::vector<std::string> fnmk;

	InclPrintConsumer(llvm::raw_ostream* o ,CompilerInstance* MI): Out(*o),MyCI(MI) 
	{}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
	

		SourceManager* scm = & MyCI->getSourceManager();
		for(clang::SourceManager::fileinfo_iterator i = scm->fileinfo_begin();i!=scm->fileinfo_end();i++)
		{
			
			
			if(i->first->getUID() == scm->getFileEntryForID(scm->getMainFileID())->getUID() )
				continue;
			if(!scm->isInSystemHeader(scm->getLocation(i->first,1,1)))
				continue;

			std::string fn(i->first->getName());
			fn = fn.substr(fn.find_last_of("/\\")+1);
			
			if(std::find(fnmk.begin(),fnmk.end(),fn)!=fnmk.end())
				continue;

			fnmk.push_back(fn);

			Out.write("#include <",10);
			Out.write(fn.c_str(),fn.size() );
			Out.write(">\n",2);
		}
	}
};


class PrintConsumer : public ASTConsumer {
public:

	llvm::raw_ostream &Out;
	CompilerInstance* MyCI;
	
	PrintConsumer(llvm::raw_ostream* o ,CompilerInstance* MI): Out(*o),MyCI(MI) 
	{}

	virtual void HandleTopLevelDecl(DeclGroupRef D) {
		
		if(D.isSingleDecl())
			if( (MyCI->getSourceManager().isInSystemHeader(D.getSingleDecl()->getLocation()) ))
		{
			return;
		}
		
		if(D.isDeclGroup())
			if( MyCI->getSourceManager().isInSystemHeader(D.getDeclGroup()[0]->getLocation() ))
		{
			return;
		}

		PrintingPolicy Policy = MyCI->getASTContext().PrintingPolicy;
		Policy.Dump = false;
		NullStmt* nstm = new (MyCI->getASTContext()) NullStmt(SourceLocation());

		
		DeclGroupRef::iterator it;
		for(it = D.begin();
			it != D.end();
			it++) {
				
				(*it)->print(Out,Policy);
				nstm->printPretty(Out,NULL,Policy);
		}
	}
};